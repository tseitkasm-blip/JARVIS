package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var waitingForCommand = false
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        } else startWakeWord()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFF030A16.toInt())
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 34f
            letterSpacing = 0.18f
            setTextColor(0xFF39D5FF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL AI SYSTEM  •  REDMI EDITION"
            textSize = 11f
            letterSpacing = 0.12f
            setTextColor(0xFF77AFC7.toInt())
            gravity = Gravity.CENTER
        }
        val orb = TextView(this).apply {
            text = "◉"
            textSize = 96f
            setTextColor(0xFF39D5FF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 20)
        }
        status = TextView(this).apply {
            text = "ИНИЦИАЛИЗАЦИЯ СИСТЕМЫ…"
            textSize = 14f
            setTextColor(0xFFB8F1FF.toInt())
            gravity = Gravity.CENTER
        }
        transcript = TextView(this).apply {
            text = "Скажи: «Джарвис»"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val listen = Button(this).apply {
            text = "ЗАПУСТИТЬ ПРОСЛУШИВАНИЕ"
            setOnClickListener { if (listening) stopListening() else startWakeWord() }
        }
        val help = TextView(this).apply {
            text = "Команды: «который час», «открой настройки», «открой YouTube», «стоп».\nДля вопросов после слова «Джарвис» пока доступен базовый режим без облачного ИИ."
            textSize = 13f
            setTextColor(0xFF77AFC7.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 28, 8, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(orb)
        root.addView(status)
        root.addView(transcript)
        root.addView(listen)
        root.addView(help)
        setContentView(root)
    }

    override fun onInit(code: Int) {
        ttsReady = code == TextToSpeech.SUCCESS
        if (ttsReady) tts.language = Locale("ru", "RU")
        status.text = if (ttsReady) "ГОТОВ К РАБОТЕ" else "ГОЛОСОВОЙ ДВИЖОК НЕ ДОСТУПЕН"
    }

    private fun startWakeWord() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Распознавание речи недоступно. Установи/включи сервис Google Speech Services."
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = if (waitingForCommand) "СЛУШАЮ КОМАНДУ…" else "ОЖИДАНИЕ СЛОВА «ДЖАРВИС»" }
            override fun onBeginningOfSpeech() { status.text = "СЛУШАЮ…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { if (listening) restartListening() }
            override fun onResults(results: Bundle?) {
                val said = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().lowercase(Locale("ru", "RU"))
                if (said.isNotBlank()) {
                    transcript.text = "Вы: $said"
                    if (!waitingForCommand && (said.contains("джарвис") || said.contains("jarvis"))) {
                        waitingForCommand = true
                        speak("Да, слушаю.")
                    } else if (waitingForCommand) {
                        waitingForCommand = false
                        handleCommand(said)
                    }
                }
                if (listening) restartListening()
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        listening = true
        restartListening()
    }

    private fun restartListening() {
        if (!listening) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            status.text = "Не удалось запустить микрофон. Нажми кнопку ещё раз."
        }
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("стоп") || command.contains("замолчи") -> { speak("Хорошо."); stopListening() }
            command.contains("время") || command.contains("час") -> speak("Сейчас ${SimpleDateFormat("HH:mm", Locale("ru", "RU")).format(Date())}")
            command.contains("дат") || command.contains("число") -> speak("Сегодня ${SimpleDateFormat("d MMMM yyyy", Locale("ru", "RU")).format(Date())}")
            command.contains("настройк") -> { speak("Открываю настройки."); startActivity(Intent(Settings.ACTION_SETTINGS)) }
            command.contains("wi-fi") || command.contains("вайфай") || command.contains("вай фай") -> { speak("Открываю настройки Wi-Fi."); startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
            command.contains("youtube") || command.contains("ютуб") -> openAppOrWeb("com.google.android.youtube", "https://www.youtube.com", "Открываю YouTube.")
            command.contains("браузер") || command.contains("интернет") || command.contains("google") -> { speak("Открываю браузер."); openUrl("https://www.google.com") }
            command.contains("кто ты") -> speak("Я Джарвис, твой голосовой помощник для Redmi.")
            command.contains("привет") -> speak("Здравствуйте. Система Джарвис готова к работе.")
            else -> speak("Я услышал: $command. Для сложных ответов подключение ИИ ещё нужно настроить.")
        }
        status.text = "ГОТОВ К СЛЕДУЮЩЕЙ КОМАНДЕ"
    }

    private fun openAppOrWeb(packageName: String, url: String, response: String) {
        speak(response)
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch) else openUrl(url)
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: ActivityNotFoundException) { Toast.makeText(this, "Не найдено приложение для открытия ссылки", Toast.LENGTH_SHORT).show() }
    }

    private fun speak(text: String) {
        transcript.text = "Джарвис: $text"
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun stopListening() {
        listening = false
        waitingForCommand = false
        try { recognizer?.stopListening() } catch (_: Exception) {}
        status.text = "ПРОСЛУШИВАНИЕ ОСТАНОВЛЕНО"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startWakeWord()
        else status.text = "Для голосового управления нужен доступ к микрофону."
    }

    override fun onPause() {
        super.onPause()
        // Android speech recognition is not guaranteed to keep listening in background.
        try { recognizer?.cancel() } catch (_: Exception) {}
    }

    override fun onDestroy() {
        listening = false
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
